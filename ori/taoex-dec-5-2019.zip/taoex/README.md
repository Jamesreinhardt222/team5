# Taoex Club readme


# Functionality
    

# Help
    Laravel MVC - Controller is where all the backend is done, values are then passed into the frontend views (blades) through routing (web.php)
    
    webhosting on cloudlogin has databases that are CASE SENSITIVE so make sure when making any database queries that you match the case on the webhosted sql server.  Locally if you're using windows and xampp then case sensitivity doesn't matter but once you push work on production then you have to look at case sensitivity.  
    
    .env file will need to be changed for live and local
    
    Gmail was used for sending out the emails for forgot password,  sometimes gmail might lock you out and force you to change password so keep that in mind
    

