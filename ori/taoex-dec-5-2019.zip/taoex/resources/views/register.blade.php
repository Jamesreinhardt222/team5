<?php echo "something wrong here";
$canadian_cities = array(
    'AB' => array(
        'Airdrie',
        'Grande Prairie',
        'Red Deer',
        'Beaumont',
        'Hanna',
        'St. Albert',
        'Bonnyville',
        'Hinton',
        'Spruce Grove',
        'Brazeau',
        'Irricana',
        'Strathcona County',
        'Breton',
        'Lacombe',
        'Strathmore',
        'Calgary',
        'Leduc',
        'Sylvan Lake',
        'Camrose',
        'Lethbridge',
        'Swan Hills',
        'Canmore',
        'McLennan',
        'Taber',
        'Didzbury',
        'Medicine Hat',
        'Turner Valley',
        'Drayton Valley',
        'Olds',
        'Vermillion',
        'Edmonton',
        'Onoway',
        'Wood Buffalo',
        'Ft. Saskatchewan',
        'Provost'
    ),
    'British Columbia' => array(
        'Burnaby',
        'Lumby',
        'Port Moody',
        'Cache Creek',
        'Maple Ridge',
        'Prince George',
        'Castlegar',
        'Merritt',
        'Prince Rupert',
        'Chemainus',
        'Mission',
        'Richmond',
        'Chilliwack',
        'Nanaimo',
        'Saanich',
        'Clearwater',
        'Nelson',
        'Sooke',
        'Colwood',
        'New Westminster',
        'Sparwood',
        'Coquitlam',
        'North Cowichan',
        'Surrey',
        'Cranbrook',
        'North Vancouver',
        'Terrace',
        'Dawson Creek',
        'North Vancouver',
        'Tumbler',
        'Delta',
        'Osoyoos',
        'Vancouver',
        'Fernie',
        'Parksville',
        'Vancouver',
        'Invermere',
        'Peace River',
        'Vernon',
        'Kamloops',
        'Penticton',
        'Victoria',
        'Kaslo',
        'Port Alberni',
        'Whistler',
        'Langley',
        'Port Hardy'
    ),
    'MB' => array(
        'Birtle',
        'Flin Flon',
        'Swan River',
        'Brandon',
        'Snow Lake',
        'The Pas',
        'Cranberry Portage',
        'Steinbach',
        'Thompson',
        'Dauphin',
        'Stonewall',
        'Winnipeg'
    ),
    'NB' => array(
        'Cap-Pele',
        'Miramichi',
        'Saint John',
        'Fredericton',
        'Moncton',
        'Saint Stephen',
        'Grand Bay-Westfield',
        'Oromocto',
        'Shippagan',
        'Grand Falls',
        'Port Elgin',
        'Sussex',
        'Memramcook',
        'Sackville',
        'Tracadie-Sheila'
    ),
    'NL' => array(
        'Hay River',
        'Mount Pearl ',
        'St. John\'s'
    ),
    'NT' => array(
        'Corner Brook',
        'Inuvik',
        'YellowKnife'
    ),
    'NS' => array(
        'Amherst',
        'Hants County',
        'Pictou',
        'Annapolis',
        'Inverness County',
        'Pictou County',
        'Argyle',
        'Kentville',
        'Queens',
        'Baddeck',
        'County of Kings',
        'Richmond',
        'Bridgewater',
        'Lunenburg',
        'Shelburne' . 'Cape Breton',
        'Lunenburg County',
        'Stellarton',
        'Chester',
        'Mahone Bay',
        'Truro',
        'Cumberland County',
        'New Glasgow',
        'Windsor',
        'East Hants',
        'New Minas',
        'Yarmouth',
        'Halifax',
        'Parrsboro'
    ),
    'NU' => array(
        'Iqaluit'
    ),
    'ON' => array(
        'Ajax',
        'Halton',
        'Peterborough',
        'Atikokan',
        'Halton Hills',
        'Pickering',
        'Barrie',
        'Hamilton',
        'Port Bruce',
        'Belleville',
        'Hamilton-Wentworth',
        'Port Burwell',
        'Blandford-Blenheim',
        'Hearst',
        'Port Colborne',
        'Blind River',
        'Huntsville',
        'Port Hope',
        'Brampton',
        'Ingersoll',
        'Prince Edward',
        'Brant',
        'James',
        'Quinte West',
        'Brantford',
        'Kanata',
        'Renfrew',
        'Brock',
        'Kincardine',
        'Richmond Hill',
        'Brockville',
        'King',
        'Sarnia',
        'Burlington',
        'Kingston',
        'Sault Ste. Marie',
        'Caledon',
        'Kirkland Lake',
        'Scarborough',
        'Cambridge',
        'Kitchener',
        'Scugog',
        'Chatham-Kent',
        'Larder Lake',
        'Souix Lookout CoC',
        'Sioux Lookout',
        'Chesterville',
        'Leamington',
        'Smiths Falls',
        'Clarington',
        'Lennox-Addington',
        'South-West Oxford',
        'Cobourg',
        'Lincoln',
        'St. Catharines',
        'Cochrane',
        'Lindsay',
        'St. Thomas',
        'Collingwood',
        'London',
        'Stoney Creek',
        'Cornwall',
        'Loyalist Township',
        'Stratford',
        'Cumberland',
        'Markham',
        'Sudbury',
        'Deep River',
        'Metro Toronto',
        'Temagami',
        'Dundas',
        'Merrickville',
        'Thorold',
        'Durham',
        'Milton',
        'Thunder Bay',
        'Dymond',
        'Nepean',
        'Tillsonburg',
        'Ear Falls',
        'Newmarket',
        'Timmins',
        'East Gwillimbury',
        'Niagara',
        'Toronto',
        'East Zorra-Tavistock',
        'Niagara Falls',
        'Uxbridge',
        'Elgin',
        'Niagara-on-the-Lake',
        'Vaughan',
        'Elliot Lake',
        'North Bay',
        'Wainfleet',
        'Flamborough',
        'North Dorchester',
        'Wasaga Beach',
        'Fort Erie',
        'North Dumfries',
        'Waterloo',
        'Fort Frances',
        'North York',
        'Waterloo (Region)',
        'Gananoque',
        'Norwich',
        'Welland',
        'Georgina',
        'Oakville',
        'Wellesley',
        'Glanbrook',
        'Orangeville',
        'West Carleton',
        'Gloucester',
        'Orillia',
        'West Lincoln',
        'Goulbourn',
        'Osgoode',
        'Whitby',
        'Gravenhurst',
        'Oshawa',
        'Wilmot',
        'Grimsby',
        'Ottawa',
        'Windsor',
        'Guelph',
        'Ottawa-Carleton',
        'Woolwich',
        'Haldimand-Norfork',
        'Owen Sound',
        'York',
        'Oxford'
    ),
    'PE' => array(
        'Alberton',
        'Montague',
        'Stratford',
        'Charlottetown',
        'Souris',
        'Summerside',
        'Cornwall'
    ),
    'QC' => array(
        'Acton Vale',
        'Alma',
        'Amos',
        'Amqui',
        'Asbestos',
        'Baie-Comeau',
        'Baie-d\'Urfé',
        'Baie-Saint-Paul',
        'Barkmere',
        'Beaconsfield',
        'Beauceville',
        'Beauharnois',
        'Beaupré',
        'Bécancour',
        'Bedford',
        'Belleterre',
        'Beloeil',
        'Berthierville',
        'Blainville',
        'Bois-des-Filion',
        'Boisbriand',
        'Bonaventure',
        'Boucherville',
        'Brome Lake',
        'Bromont',
        'Brossard',
        'Brownsburg-Chatham',
        'Candiac',
        'Cap-Chat',
        'Cap-Santé',
        'Carignan',
        'Carleton-sur-Mer',
        'Causapscal',
        'Chambly',
        'Chandler',
        'Chapais',
        'Charlemagne',
        'Château-Richer',
        'Châteauguay',
        'Chibougamau',
        'Clermont',
        'Coaticook',
        'Contrecoeur',
        'Cookshire-Eaton',
        'Coteau-du-Lac',
        'Côte Saint-Luc',
        'Cowansville',
        'Danville',
        'Daveluyville',
        'Dégelis',
        'Delson',
        'Desbiens',
        'Deux-Montagnes',
        'Disraeli',
        'Dolbeau-Mistassini',
        'Dollard-des-Ormeaux',
        'Donnacona',
        'Dorval',
        'Drummondville',
        'Dunham',
        'Duparquet',
        'East Angus',
        'Estérel',
        'Farnham',
        'Fermont',
        'Forestville',
        'Fossambault-sur-le-Lac',
        'Gaspé',
        'Gatineau',
        'Gracefield',
        'Granby',
        'Grande-Rivière',
        'Hampstead',
        'Hudson',
        'Huntingdon',
        'Joliette',
        'Kingsey Falls',
        'Kirkland',
        'L\'Ancienne-Lorette',
        'L\'Assomption',
        'L\'Épiphanie',
        'L\'Île-Cadieux',
        'L\'Île-Dorval',
        'L\'Île-Perrot',
        'La Malbaie',
        'La Pocatière',
        'La Prairie',
        'La Sarre',
        'La Tuque',
        'Lac-Delage',
        'Lac-Mégantic',
        'Lac-Saint-Joseph',
        'Lac-Sergent',
        'Lachute',
        'Laval',
        'Lavaltrie',
        'Lebel-sur-Quévillon',
        'Léry',
        'Lévis',
        'Longueuil',
        'Lorraine',
        'Louiseville',
        'Macamic',
        'Magog',
        'Malartic',
        'Maniwaki',
        'Marieville',
        'Mascouche',
        'Matagami',
        'Matane',
        'Mercier',
        'Métabetchouan–Lac-à-la-Croix',
        'Métis-sur-Mer',
        'Mirabel',
        'Mont-Joli',
        'Mont-Laurier',
        'Mont-Saint-Hilaire',
        'Mont-Tremblant',
        'Montmagny',
        'Montreal',
        'Montreal West (Montréal-Ouest)',
        'Montréal-Est',
        'Mount Royal (Mont-Royal)',
        'Murdochville',
        'Neuville',
        'New Richmond',
        'Nicolet',
        'Normandin',
        'Notre-Dame-de-l\'Île-Perrot',
        'Notre-Dame-des-Prairies',
        'Otterburn Park',
        'Paspébiac',
        'Percé',
        'Pincourt',
        'Plessisville',
        'Pohénégamook',
        'Pointe-Claire',
        'Pont-Rouge',
        'Port-Cartier',
        'Portneuf',
        'Prévost',
        'Princeville',
        'Quebec City',
        'Repentigny',
        'Richelieu',
        'Richmond',
        'Rimouski',
        'Rivière-du-Loup',
        'Rivière-Rouge',
        'Roberval',
        'Rosemère',
        'Rouyn-Noranda',
        'Saguenay',
        'Saint-Augustin-de-Desmaures',
        'Saint-Basile',
        'Saint-Basile-le-Grand',
        'Saint-Bruno-de-Montarville',
        'Saint-Césaire',
        'Saint-Colomban',
        'Saint-Constant',
        'Saint-Eustache',
        'Saint-Félicien',
        'Saint-Gabriel',
        'Saint-Georges',
        'Saint-Hyacinthe',
        'Saint-Jean-sur-Richelieu',
        'Saint-Jérôme',
        'Saint-Joseph-de-Beauce',
        'Saint-Joseph-de-Sorel',
        'Saint-Lambert',
        'Saint-Lazare',
        'Saint-Lin-Laurentides',
        'Saint-Marc-des-Carrières',
        'Saint-Ours',
        'Saint-Pamphile',
        'Saint-Pascal',
        'Saint-Pie',
        'Saint-Raymond',
        'Saint-Rémi',
        'Saint-Sauveur',
        'Saint-Tite',
        'Sainte-Adèle',
        'Sainte-Agathe-des-Monts',
        'Sainte-Anne-de-Beaupré',
        'Sainte-Anne-de-Bellevue',
        'Sainte-Anne-des-Monts',
        'Sainte-Anne-des-Plaines',
        'Sainte-Catherine',
        'Sainte-Catherine-de-la-Jacques-Cartier',
        'Sainte-Julie',
        'Sainte-Marguerite-du-Lac-Masson',
        'Sainte-Marie',
        'Sainte-Marthe-sur-le-Lac',
        'Sainte-Thérèse',
        'Salaberry-de-Valleyfield',
        'Schefferville',
        'Scotstown',
        'Senneterre',
        'Sept-Îles',
        'Shawinigan',
        'Sherbrooke',
        'Sorel-Tracy',
        'Stanstead',
        'Sutton',
        'Témiscaming',
        'Témiscouata-sur-le-Lac',
        'Terrebonne',
        'Thetford Mines',
        'Thurso',
        'Trois-Pistoles',
        'Trois-Rivières',
        'Val-d\'Or',
        'Valcourt',
        'Varennes',
        'Vaudreuil-Dorion',
        'Victoriaville',
        'Ville-Marie',
        'Warwick',
        'Waterloo',
        'Waterville',
        'Westmount',
        'Windsor'
    ),
    'SK' => array(
        'Avonlea',
        'Melfort',
        'Swift Current',
        'Colonsay',
        'Nipawin',
        'Tisdale',
        'Craik',
        'Prince Albert',
        'Unity',
        'Creighton',
        'Regina',
        'Weyburn',
        'Eastend',
        'Saskatoon',
        'Wynyard',
        'Esterhazy',
        'Shell Lake',
        'Yorkton',
        'Gravelbourg'
    ),
    'YT' => array(
        'Whitehorse',
        'Dawson City',
        'Faro',
        'Watson Lake'
    )
);
$province = $_GET['province'];
function writeCities($province, $canada) {
  foreach($canada as $canadian_province) {
    if ($canadian_province == $province) {
      foreach($canadian_province as $city) {
        echo "<option" . "value='" . $city . "'>" . $city . "</option>";
      }
    }
  }
}
/*
if(strcmp($_GET['province'],'bc')){
    $canadian_cities = bclist;
}
*/

?>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>TAOEX</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Bootstrap select CSS -->
  <link href="vendor/bootstrap_select/css/bootstrap-select.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>
<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="fName">First name</label>
                <input class="form-control" id="fName" type="text" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="lName">Last name</label>
                <input class="form-control" id="lName" type="text" placeholder="Enter last name">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="email">Email address</label>
            <input class="form-control" id="email" type="email" aria-describedby="emailHelp" placeholder="Enter Email">
          </div>
          <div class="form-group">
            <label for="phone-number">Phone number</label>
            <input class="form-control" id="phone-number" type="text" placeholder="Enter Phone Number">
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input class="form-control" id="address" type="text" placeholder="Enter home address">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <select class="form-control" id="province" name="province">
                  <option value="AB">Alberta</option>
                  <option value="BC">British Columbia</option>
                  <option value="MB">Manitoba</option>
                  <option value="NB">New Brunswich</option>
                  <option value="NL">Newfoundland and Labrador</option>
                  <option value="NT">Northwest Territories</option>
                  <option value="NS">Nova Scotia</option>
                  <option value="NU">Nunavut</option>
                  <option value="ON">Ontaria</option>
                  <option value="PE">Prince Edward Island</option>
                  <option value="QC">Quebec</option>
                  <option value="SK">Saskatchewan</option>
                  <option value="YT">Yukon</option>
                </select>
              </div>
              <div class="col-md-6">
                <select class="form-control" id="cities" name="cities">
                	<?php if (strlen($user->province)>1 ) 
					echo "<option value="."$user->province"."selected='selected >"."$user->province"."</option>";?>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Password</label>
                <input class="form-control" id="exampleInputPassword1" type="password" placeholder="Password">
              </div>
              <div class="col-md-6">
                <label for="exampleConfirmPassword">Confirm password</label>
                <input class="form-control" id="exampleConfirmPassword" type="password" placeholder="Confirm password">
              </div>
            </div>
          </div>
          <a class="btn btn-primary btn-block" href="login.html">Register</a>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="login.html">Login Page</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/popper/popper.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Bootstrap select JS -->
  <script src="vendor/bootstrap_select/js/bootstrap-select.min.js"></script>
  <script src="js/taoex.js"></script>
  <script type="text/javascript">
  </script>
  
  <footer class="footer">
  <div class="container text-center">
    {{-- <span class="text-muted"><a href="{{ route('policy') }}">Privacy Policy</a></span> --}}
    <small>Copyright © Taoex <?php echo date ("Y");?></small>

    <span class="text-muted"><a href="policy">Privacy Policy</a></span>
  </div>
</footer>

</body>

</html>