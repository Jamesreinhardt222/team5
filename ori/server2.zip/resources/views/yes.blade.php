Message sent!
<script>
        window.location.replace("/home/");
</script>