<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="background-color:#d7d9e9">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb" style="background-color:white; margin-top:10px">
            <li class="breadcrumb-item">
                <a href="#">Taoex</a>
            </li>
            <li class="breadcrumb-item active">Dashboard</li>
            <!-- user card -->
        <br><div class="h3">Welcome, <span class="color-primary"><?php echo e(strtoupper(Auth::user()->firstName)); ?> <?php echo e(strtoupper(Auth::user()->lastName)); ?> </span></div>
        </ol>

        
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-3 text-center border-dark bg-secondary">
                    <div class="card-header h4" style="color:white">
                        Personal Information
                    </div>
                    <div class="card-body">
                        <div>
                        <?php
                            $image = App\Utility::get_image_fromTable(Auth::user()->id,'users');
                        ?>
                         
                        <img src="<?php echo e("data:image/" . $image['type'] . ";base64," . $image['data']); ?>" style="border-radius:50%; margin-bottom:15px;">

                        </div>
                        <ul class="list-group" style="color:gray">
                            <li class="list-group-item" style="font-weight: bold;">User Level: <span style="text-align: right;"><?php echo e((Auth::user()->type == 1) ? 'Club Owner' : 'Normal'); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Club: <span style="text-align: right;" ><?php echo e(isset($club) ? $club->name : 'None'); ?> 
                            <a class="btn btn-outline-success" style="display:<?php if(Auth::user()->club_id == null): ?> '' <?php else: ?> none <?php endif; ?>; width:5rem" 	
                            href="/home/newclub">Create</a></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Total Score: <span style="text-align: right;"><?php echo e($totalScore); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Ranking: <span style="text-align: right;">
                            
                            <a href="/home/ranking"><?php echo e($ranking); ?></a></span></li>

                            <li class="list-group-item" style="font-weight: bold;">
                                <a class="btn btn-outline-secondary" style="width:5rem" href="<?php echo e(route('editUser',Auth::user()->id)); ?>">Edit</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <a class="btn btn-outline-secondary" style="width:5rem; text-align:center" href="<?php echo e(route('deleteUser',Auth::user()->id)); ?>">Delete</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
            	<div class="row">
            	<div class="col-md-12">
            	 <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert" style="margin-top:20px">
            <strong><?php echo e($errors->first()); ?></strong> &nbsp;&nbsp;
            <a class="btn btn-success" href="/home/newclub">Create a Club</a>
        </div>
      <?php endif; ?>  
    
            	<div class="panel-group">
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h4 class="panel-title">
        <button type="button" class="btn btn-secondary" data-toggle="collapse" href="#collapse1" style="width:100%">Messages</button>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse show">
      <ul class="list-group">
        <li class="list-group-item" style="overflow:auto">
                    <table class="table table-striped table-bordered">
                        <thead>
                            <tr data-toggle="collapse" data-target=".contents">
                                <th>Messages</th>
                                <th>Time</th>
                                <th><a href="#">Click here to view messages</a></th>
                            </tr>
                        </thead>
                        <tbody>                          
                            <?php $__currentLoopData = $userMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userMessage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="collapse contents">
                                    <td><?php echo $userMessage->message?></td>
                                    <td><?php echo $userMessage->message_id?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                        </tbody>
                    </table>
  
        </li>
      </ul>
    </div>
  </div>
<br>
    	<div class="panel-group">
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h4 class="panel-title">
        <button type="button" class="btn btn-secondary" data-toggle="collapse" href="#collapse2" style="width:100%">Recent Matches</button>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse show">
      <ul class="list-group">
        <li class="list-group-item" style="overflow:auto">
        
        
            <?php if(isset($matches)): ?>
                                
                               <table class="table table-striped table-bordered" id="example" style="overflow-x: scroll">
                                 <thead>
                                   <tr>
                                     <th>Match Name</th>
                                     <th>Address</th>
                                     <th>Start Time</th>
                                     <th>Start Date</th>
                                     <th>End Date</th>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                     <td><?php echo e($match->name); ?></td>
                                     <td><?php echo e($match->address); ?></td>
                                     <td><?php echo e($match->start_time); ?></td>
                                     <td><?php echo e($match->startDate); ?></td>
                                     <td><?php echo e($match->endDate); ?></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                               </table>
                               <span style="float:right">
                               <?php if(Auth::user()->club_id != null): ?>
                               <a class="btn btn-outline-info" style="float:left;margin-right:3px" href="/home/applyNewMatch">Create a Match</a>
                               <?php endif; ?>

                        	<a class="btn btn-outline-info" style="float:right" href=/home/allMatch>View more...</a>
                        

                </span>
                </div>
                
            <?php endif; ?>
        </li>
      </ul>
    </div>
  </div>

            <?php if(isset($club_id) && Auth::user()->approved_status == 2): ?>
            <div class="col-md-8">
                <div class="card mb-3">
                    <div class="card-header h4">Invitation</div>
                    <div class="card-body">
                        <div class="h5">You have an invitation</div>
                        <form method="GET" action="<?php echo e(action('ClubController@acceptInvitation')); ?>">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-6">Club Name:</div>
                                    <div class="col-6"> <?php echo e($club->name); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Owner:</div>
                                    <div class="col-6"></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Location:</div>
                                    <div class="col-6"><?php echo e($club->city); ?>, <?php echo e($club->province); ?></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Accept</button>
                            </div>
                        </form>
                        <form method="GET" action="<?php echo e(action('ClubController@declineInvitation')); ?>">
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger btn-block">Decline</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>

                
        <!--<div class="h4" style="display:<?php if(Auth::user()->club_id == null): ?> none <?php else: ?> '' <?php endif; ?>">Club Tournaments <hr/></div>-->
	

	
    </div>
    </div>
    
</div>
    <!-- /.container-fluid-->
</div>
<!-- /.content-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>