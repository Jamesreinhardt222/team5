<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Taoex</a>
            </li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <!-- user card -->
        <div class="h3">Welcome, <span class="color-primary"><?php echo e(strtoupper(Auth::user()->firstName)); ?> <?php echo e(strtoupper(Auth::user()->lastName)); ?> </span><hr/></div>
        <div class="row">
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header h4">
                        Personal Information
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item" style="font-weight: bold;">User Level: <span style="text-align: right;"><?php echo e((Auth::user()->type == 1) ? 'Club Owner' : 'Normal'); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Club: <span style="text-align: right;" ><?php echo e(isset($club) ? $club->name : 'None'); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Total Score: <span style="text-align: right;"><?php echo e($totalScore); ?></span></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-4" style="display:<?php if(Auth::user()->club_id == null): ?> '' <?php else: ?> none <?php endif; ?>">
                <div class="card mb-3" id="no-club">
                    <div class="card-header" style="<?php echo e(isset($error) ? 'background-color:red' : 'gray'); ?>">
                        <div class="h4">You are Not in a club yet</div>
                    </div>
                    <div class="card-body">
                        <div class="h6">Construct your own club to challange with outher club players!</div>
                        <div class="row">
                            <div class="col-12">
                                <a class="btn btn-primary btn-block btn-md" href="/home/newclub">Create</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header">
                        <div class="h4">Comments</div>
                    </div>
                    <div class="card-body">
                        <h1><?php echo e(isset($club) ? $club->comments : ''); ?></h1>
                        <?php if(isset($message)): ?>
                        <div class="alert <?php echo e($color); ?>"><?php echo e($message); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(isset($club_id) && Auth::user()->approved_status == 2): ?>
            <div class="col-8">
                <div class="card mb-3">
                    <div class="card-header h4">Invatation</div>
                    <div class="card-body">
                        <div class="h5">You have a invatation</div>
                        <form method="GET" action="<?php echo e(action('ClubController@acceptInvitation')); ?>">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-6">Club Name:</div>
                                    <div class="col-6"> <?php echo e($club->name); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Owner:</div>
                                    <div class="col-6"></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Location:</div>
                                    <div class="col-6"><?php echo e($club->city); ?>, <?php echo e($club->province); ?></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Accept</button>
                            </div>
                        </form>
                        <form method="GET" action="<?php echo e(action('ClubController@declineInvitation')); ?>">
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger btn-block">Decline</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="h4" style="display:<?php if(Auth::user()->club_id == null): ?> none <?php else: ?> '' <?php endif; ?>">Club Tournaments <hr/></div>
        <?php if(Auth::user()->club_id != null): ?>
        <div class='row'>
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header">
                        <div class="h6">New Match Application</div>
                    </div>
                    <div class="card-body">
                        <div class="h5">Let's create a new Match!</div>
                        <a class="btn btn-primary btn-block" href="/home/applyNewMatch">Apply</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="row" style="display: <?php echo e(isset($matches) ? '' : 'none'); ?>">
            <?php if(isset($matches)): ?>
            <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header h6"><?php echo e($match->name); ?></div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-5 h6">Location</div>
                            <div class="col-7"><?php echo e($match->address); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-5 h6">Start Time</div>
                            <div class="col-7"><?php echo e($match->start_time); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-5 h6">Start Date</div>
                            <div class="col-7"><?php echo e($match->startDate); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-5 h6">End Date</div>
                            <div class="col-7"><?php echo e($match->endDate); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <!-- /.container-fluid-->
</div>
<!-- /.content-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>