
<?php $__env->startSection('content'); ?>

<br>
<br>
<main class = "container-fluid" style="margin-bottom: 70px">
    <div class="card text-center text-white" style="background-color:#354359">
        <div class="card-header">
          <h3> Welcome to <i>Taoex Club</i>!</h3>
        </div>
        <div class="card-body">
                <img src="images/taoex_club_logo_3.png" alt="Card image cap">

          <h5 class="card-title">The Integrated Administration to Taoex the Game </h5>
          <p class="card-text">Create and record matches.</br>
            View Match Results.</br>
            Create and update your profile.</br>
            Form Clubs and compete!</br>    
          </p>
          <a href="/register" class="btn btn-primary">Sign up</a>
          <a href="/login" class="btn btn-success">Login</a>

        </div>
    </div>

    <br>
    <div class="card-deck">
            <div class="card bg-dark text-white">
              <img class="card-img-top" src="images/taoex_card2.png" alt="Card image cap">
              <div class="card-body">
                <h3 class="card-title">Club Rankings</h3>
                <div class="container-fluid scroll">
                         <p>Number of Clubs: <?php echo $club_count; ?></p>            
                        <table class="table table-bordered" style="overflow-x: scroll">
                          <thead>
                            <tr>
                              <th>Club Names</th>
                              <th>Owner</th>
                              <th>City</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($club->name); ?></td>
                              <td><?php echo e($club->firstName); ?> <?php echo e($club->lastName); ?></td>
                              <td><?php echo e($club->city); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="images/temp.svg" alt="Card image cap">
              <div class="card-body">
                <h5 class="card-title">Individual Rankings</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
            <div class="card">
              <img class="card-img-top" src="images/temp.svg" alt="Card image cap">
              <div class="card-body">
                <h5 class="card-title">Recent News</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
              </div>
            </div>
          </div>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>