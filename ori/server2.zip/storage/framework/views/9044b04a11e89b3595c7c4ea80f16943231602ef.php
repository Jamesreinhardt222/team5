<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>TAOEX</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Bootstrap select CSS -->
  <link href="vendor/bootstrap_select/css/bootstrap-select.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>
<body class="bg-dark">
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form type="post">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="fName">First name</label>
                <input class="form-control" id="fName" type="text" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="lName">Last name</label>
                <input class="form-control" id="lName" type="text" placeholder="Enter last name">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="email">Email address</label>
            <input class="form-control" id="email" type="email" aria-describedby="emailHelp" placeholder="Enter Email">
          </div>
          <div class="form-group">
            <label for="phone-number">Phone number</label>
            <input class="form-control" id="phone-number" type="text" placeholder="Enter Phone Number">
          </div>
          <div class="form-group">
            <label for="address">Address</label>
            <input class="form-control" id="address" type="text" placeholder="Enter home address">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="country">Province</label>
                <select class="form-control" id="country" name="country">
                </select>
              </div>
              <div class="col-md-6">
                <label for="state">City</label>
                <select class="form-control" id="state" name="state">
                </select>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Password</label>
                <input class="form-control" id="exampleInputPassword1" type="password" placeholder="Password">
              </div>
              <div class="col-md-6">
                <label for="exampleConfirmPassword">Confirm password</label>
                <input class="form-control" id="exampleConfirmPassword" type="password" placeholder="Confirm password">
              </div>
            </div>
          </div>
          <a class="btn btn-primary btn-block" href="login.html">Register</a>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="login.html">Login Page</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/popper/popper.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Bootstrap select JS -->
  <script src="vendor/bootstrap_select/js/bootstrap-select.min.js"></script>
  <script src="js/taoex.js"></script>
  <script type= "text/javascript" src="js/canada.js">
  </script>
</body>

</html>
