<script>
   $(document).ready(function() {
    $('#member').DataTable()( {
     aaSorting: [[0, 'asc']]
});
} );
</script>
<div class="card-body">
                  <div class="card-body">
                  
                  
                  <form method="POST" action="<?php echo e(action('ClubController@clubMemberRanking')); ?>">
                                <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                    <small><b>Rankings for the Year of:</b></small>
                                   
 					<input type="number" id="year" name="year"
                                        min="2010" max="2018" value="2018" value="" />
                                    <span class="validity"></span>   
                                     <input type="submit" class="btn btn-primary">
                            </div> 
                             <hr>  
                        </form>
                        
                       
                      <div class="table-responsive data-table">
                        <table id="member" class="table table-bordered" width="100%" cellspacing="0">
                          <thead>
                            <tr>
                              <th>Rank</th>
                              <th>Name</th>
                              <th>Role</th>
                              <th>Total Games</th>
                              <th>Won</td>
                              <th>Score</td>
                            </tr>
                          </thead>
                          <tbody>
                          
                          <?php $__currentLoopData = $memberData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $memberDatum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                            <tr>
                            <td><?php echo e($memberDatum['rank']); ?></td>
                              <td><?php echo e($memberDatum['name']); ?></td>
                              
                              <td><?php if($memberDatum['role'] == 1): ?> Club Owner <?php else: ?> Club Member <?php endif; ?></td>
                              <td><?php echo e($memberDatum['games']); ?></td>
                              <td><?php echo e($memberDatum['won']); ?></td>
                              <td><?php echo e($memberDatum['score']); ?></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>