
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="/home">Taoex</a>
      </li>
      <li class="breadcrumb-item active">Club</li>
    </ol>
    <!-- Card -->
    <div class="h4">Club Profile <hr/> </div>
    <div class="row">
      <div class="col-6">
        <div class="card mb-3">
          <div class="card-header h4"><?php echo e(isset($club) ? $club->name : 'No-name'); ?></div>
          <dvi class="card-body">
          <div class="row">
            <div class="col-5 h6">Club Owner:</div>
            <div class="col-7"><?php echo e($clubOwner->firstName); ?> <?php echo e($clubOwner->lastName); ?></div>
          </div>
          <div class="row">
            <div class="col-5 h6">Club Location:</div>
            <div class="col-7"><?php echo e($club->city); ?></div>
          </div>
          <div class="row">
            <div class="col-5 h6">Members:</div>
            <div class="col-7"><?php echo e($numberMembers); ?></div>
          </div>
          <div class="row">
            <div class="col-5 h6">Ranking:</div>
            <div class="col-7">N/A</div>
          </div>
          </dvi>
        </div>
      </div>
      <div class="col-6">
        <div class="card mb-3">
          <div class="card-header h6">Find New Member</div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(action('ClubController@invite')); ?>">
              <div class="form-group">
                <label for="player" class="control-label">Near Players <?php echo e(isset($nearPlayer) ? 'yes' : 'no-player'); ?></label>
                <select class="form-control" id="player" name="player">
                  <option>Find players near to you</option>
                  <?php $__currentLoopData = $nearPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nearPlayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($nearPlayer->id); ?>"><?php echo e($nearPlayer->firstName); ?> <?php echo e($nearPlayer->lastName); ?>, <?php echo e($nearPlayer->city); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" value="<?php echo e($club->id); ?>" id="club_id" name="club_id">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-primary form-control">Invite</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="h4">Club Match <hr/> </div>
    <div class="row" style="display: <?php echo e(isset($matches) ? '' : 'none'); ?>">
      <?php if(isset($matches)): ?>
      <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-4">
        <div class="card matches mb-3">
          <!-- Calendar -->
          <!-- card -->
          <div class="card-header h6"><?php echo e($match->name); ?></div>
          <div class="card-body">
            <div class="row">
              <div class="col-5 h6">Location</div>
              <div class="col-7"><?php echo e($match->address); ?></div>
            </div>
            <div class="row">
              <div class="col-5 h6">Start Time</div>
              <div class="col-7"><?php echo e($match->start_time); ?></div>
            </div>
            <div class="row">
              <div class="col-5 h6">Start Date</div>
              <div class="col-7"><?php echo e($match->startDate); ?></div>
            </div>
            <div class="row">
              <div class="col-5 h6">End Date</div>
              <div class="col-7"><?php echo e($match->endDate); ?></div>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
    <div class="row">
      <div class="col-4">
        <div class="card matches mb-3">
          <!-- Calendar -->
          <!-- card -->
          <div class="card-header h6">New Match Application Form</div>
          <div class="card-body">
            <div class="row">
              <div>Do you want to have a new match?</div>
            </div>
            <div class="row">
              <a class="btn btn-primary btn-block" href="/home/applyNewMatch">Apply</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h4">Match Record<hr/></div>
    <div class="row">
      <div class="col-6">
        <div class="card mb-3">
          <div class="card-header">Please Record Match Result Here</div>
          <div class="card-body">
            <form method="POST" action="<?php echo e(action('ApplyMatchController@record')); ?>">
              <div class="form-group">
                <label class="label-control">Select Match</label>
                <select class="form-control" id="match_id" name="match_id">
                  <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($match->id); ?>"><?php echo e($match->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label class="label-control">Select Player</label>
                <select class="form-control" id="player_id" name="player_id">
                  <?php $__currentLoopData = $clubMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($member->id); ?>"><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <label for="numberPlayers">NumberPlayers</label>
                <input type="number" class="form-control" id="numberPlayers" name="numberPlayers" placeholder="" Max="8" required="true">
              </div>
              <div class="form-group">
                <label for="elimination">Elimination</label>
                <input type="number" class="form-control" id="elimination" name="elimination" placeholder="" required="true">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              </div>
              <div class="form-group">
                <label for="capture">Capture</label>
                <input type="number" class="form-control" id="capture" name="capture" required="true">
              </div>
              <div class="form-group">
                <label for="hook">Hook Tiles</label>
                <input type="number" class="form-control" id="hook" name="hook" placeholder="" required="true">
              </div>
              <div class="form-group">
                <label for="winBonus">Victory By:</label>
                <Select class="form-control" id="winBonus" name="winBonus">
                  <option value="0">Not a winner</option>
                  <option value="6">Winner</option>
                  <option value="5">Liberation</option>
                  <option value="10">Arition</option>
                </Select>
              </div>
              <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="h4">Club Members <hr/> </div>
    <div class="card mb-3">
      <div class="card-header">
        Club Member List
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Memebers</th>
                <th>Rank</th>
                <th>Role</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $clubMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($member->firstName); ?> <?php echo e($member->lastName); ?></td>
                <td>N/A</td>
                <td><?php if($member->type == 1): ?> Club Owner <?php else: ?> Club Member <?php endif; ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid-->
<!-- /.content-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>