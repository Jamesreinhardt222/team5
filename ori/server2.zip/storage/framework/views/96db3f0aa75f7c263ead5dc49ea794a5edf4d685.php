
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Taoex</a>
            </li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>

        <!-- user card -->
        <div class="h3">Welcome, <span class="color-primary"><?php echo e(strtoupper(Auth::user()->firstName)); ?> <?php echo e(strtoupper(Auth::user()->lastName)); ?> </span><hr/></div>
        <div class="row">
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header h4">
                        Personal Information
                    </div>
                    <div class="card-body">
                        <div>
                        <?php
                            $userImage = DB::table('users_pic')
                                ->where('users_id', Auth::user()->id)
                                ->first();
                            
                            if (($userImage) && ( $userImage->image ) ) {
                                $imageType = $userImage->image_type;
                                $data  = $userImage->image;  
                            }else{
                                    $path = realpath("./images");
                                    $file = $path . "/empty_profile.png";
                                    $imageStr = (string) Image::make( $file)->
                                        resize( 250, null, function ( $constraint ) {
                                            $constraint->aspectRatio();
                                        })->encode( 'png' );
                                    $data = base64_encode($imageStr);  
                                    $imageType = "png";
                            }
                        ?>
                         
                        <img src="<?php echo e("data:image/" . $imageType . ";base64," . $data); ?>">

                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item" style="font-weight: bold;">User Level: <span style="text-align: right;"><?php echo e((Auth::user()->type == 1) ? 'Club Owner' : 'Normal'); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Club: <span style="text-align: right;" ><?php echo e(isset($club) ? $club->name : 'None'); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">Total Score: <span style="text-align: right;"><?php echo e($totalScore); ?></span></li>
                            <li class="list-group-item" style="font-weight: bold;">
                                <a href="<?php echo e(route('editUser',Auth::user()->id)); ?>">Edit</a>&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="<?php echo e(route('deleteUser',Auth::user()->id)); ?>">Delete</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-4" style="display:<?php if(Auth::user()->club_id == null): ?> '' <?php else: ?> none <?php endif; ?>">
                <div class="card mb-3" id="no-club">
                    <div class="card-header" style="<?php echo e(isset($error) ? 'background-color:red' : 'gray'); ?>">
                        <div class="h4">You are not in a club yet</div>
                    </div>
                    <div class="card-body">
                        <div class="h6">Construct your own club to challange with other club players!</div>
                        <div class="row">
                            <div class="col-12">
                                <a class="btn btn-primary btn-block btn-md" href="/site/home/newclub">Create</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header">
                        <div class="h4">Comments</div>
                    </div>
                    <div class="card-body">
                        <h1><?php echo e(isset($club) ? $club->comments : ''); ?></h1>
                        <?php if(isset($message)): ?>
                        <div class="alert <?php echo e($color); ?>"><?php echo e($message); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if(isset($club_id) && Auth::user()->approved_status == 2): ?>
            <div class="col-8">
                <div class="card mb-3">
                    <div class="card-header h4">Invitation</div>
                    <div class="card-body">
                        <div class="h5">You have an invitation</div>
                        <form method="GET" action="<?php echo e(action('ClubController@acceptInvitation')); ?>">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-6">Club Name:</div>
                                    <div class="col-6"> <?php echo e($club->name); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Owner:</div>
                                    <div class="col-6"></div>
                                </div>
                                <div class="row">
                                    <div class="col-6">Club Location:</div>
                                    <div class="col-6"><?php echo e($club->city); ?>, <?php echo e($club->province); ?></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block">Accept</button>
                            </div>
                        </form>
                        <form method="GET" action="<?php echo e(action('ClubController@declineInvitation')); ?>">
                            <div class="form-group">
                                <button type="submit" class="btn btn-danger btn-block">Decline</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-12">
                
        <div class="h4" style="display:<?php if(Auth::user()->club_id == null): ?> none <?php else: ?> '' <?php endif; ?>">Club Tournaments <hr/></div>
        <?php if(Auth::user()->club_id != null): ?>
        <div class='row'>
            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header">
                        <div class="h6">New Match Application</div>
                    </div>
                    <div class="card-body">
                        <div class="h5">Let's create a new Match!</div>
                        <a class="btn btn-primary btn-block" href="/home/applyNewMatch">Apply</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="row" style="display: <?php echo e(isset($matches) ? '' : 'none'); ?>">
            <?php if(isset($matches)): ?>
            <div class="col-12">
                <div class="card mb-3">
                        <div class="container-fluid scroll">
                                
                               <table class="table table-striped table-bordered" id="example" style="overflow-x: scroll">
                                 <thead>
                                   <tr>
                                     <th>Match Name</th>
                                     <th>Address</th>
                                     <th>Start Time</th>
                                     <th>Start Date</th>
                                     <th>End Date</th>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                     <td><?php echo e($match->name); ?></td>
                                     <td><?php echo e($match->address); ?></td>
                                     <td><?php echo e($match->start_time); ?></td>
                                     <td><?php echo e($match->startDate); ?></td>
                                     <td><?php echo e($match->endDate); ?></td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                               </table>
                            </div>
                </div>
                <div style="float:right">
                        <a href=/home/allMatch>more...</a>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
    </div>
</div>
    <!-- /.container-fluid-->
</div>
<!-- /.content-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>