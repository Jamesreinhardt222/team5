


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Unsubscribe</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('deleteUserAction', $userinfo->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                            <div class="form-group">
                                <p> Caution: When you click the confirm button below 
                                    which means you agree to delete any register information from Taoex and you can't log on anymore.</p>
                                <button type="submit" class="btn btn-primary">Confirm</button> 
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>