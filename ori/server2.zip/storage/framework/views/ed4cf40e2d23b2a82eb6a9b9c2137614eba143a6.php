
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Taoex</a>
      </li>
      <li class="breadcrumb-item active">Match History</li>
      <input data-provide="datepicker" class="pull-right form-contorl">
    </ol>
    <div class="h1">Match History</div>
    <div class="date-picker"></div>
    <hr>
    
    <!-- match history -->
    <?php if($results != null): ?>
    <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3">
      <div class="card-header">
        <?php echo e($match->name); ?>

      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Player</th>
                <th>Hook Tiles</th>
                <th>Captures</th>
                <th>Eliminated</th>
                <th>Win Bonus</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($result->match_id == $match->id): ?>
              <tr>
                <td><?php echo e($result->firstName); ?> <?php echo e($result->lastName); ?> <?php if($result->winBonus != 0): ?> <span style="color: red; font-size:14px">(Victory)</span><?php endif; ?></td>
                <td><?php echo e($result->hook); ?></td>
                <td><?php echo e($result->capture); ?></td>
                <td><?php echo e($result->elimination); ?></td>
                <td><?php echo e($result->winBonus); ?></td>
                <td><?php echo e($result->total); ?></td>
              </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- /.container-fluid-->
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>